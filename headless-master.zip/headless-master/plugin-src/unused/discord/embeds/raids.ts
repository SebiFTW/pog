import { Channels } from './../config.json';
import { CreateEmbed } from './embed-functions';

import { Client, EmbedField, Message } from 'eris';
import { RealmPortal } from '../../models';
import moment = require('moment');

export default class RaidEmbeds {
	public async sendRaidNotification() {

	}

	public async sendStaffMemberNotfication() {

	}
}