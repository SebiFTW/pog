export class CommandHandler {

    constructor() {

    }
}