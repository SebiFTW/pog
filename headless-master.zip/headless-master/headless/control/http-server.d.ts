export declare class HttpServer {
    constructor(port?: number);
}
