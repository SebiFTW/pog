"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const http = require('http');
const defaultHost = 'localhost';
const defaultPort = 8888;
class HttpServer {
    constructor(port = defaultPort) {
    }
}
exports.HttpServer = HttpServer;
