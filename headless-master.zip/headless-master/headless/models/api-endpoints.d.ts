/**
 * The endpoint used to retreive the list of servers and the character information about an account.
 */
export declare const SERVER_ENDPOINT = "https://realmofthemadgodhrd.appspot.com/char/list";
