"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * The object types of all classes in the game.
 */
var Classes;
(function (Classes) {
    Classes[Classes["Rogue"] = 768] = "Rogue";
    Classes[Classes["Archer"] = 775] = "Archer";
    Classes[Classes["Wizard"] = 782] = "Wizard";
    Classes[Classes["Priest"] = 784] = "Priest";
    Classes[Classes["Warrior"] = 797] = "Warrior";
    Classes[Classes["Knight"] = 798] = "Knight";
    Classes[Classes["Paladin"] = 799] = "Paladin";
    Classes[Classes["Assassin"] = 800] = "Assassin";
    Classes[Classes["Necromancer"] = 801] = "Necromancer";
    Classes[Classes["Huntress"] = 802] = "Huntress";
    Classes[Classes["Mystic"] = 803] = "Mystic";
    Classes[Classes["Trickster"] = 804] = "Trickster";
    Classes[Classes["Sorcerer"] = 805] = "Sorcerer";
    Classes[Classes["Ninja"] = 806] = "Ninja";
    Classes[Classes["Samurai"] = 785] = "Samurai";
    Classes[Classes["Bard"] = 796] = "Bard";
})(Classes = exports.Classes || (exports.Classes = {}));
