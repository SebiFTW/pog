"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * The endpoint used to retreive the list of servers and the character information about an account.
 */
exports.SERVER_ENDPOINT = 'https://realmofthemadgodhrd.appspot.com/char/list';
