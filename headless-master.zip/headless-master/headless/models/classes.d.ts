/**
 * The object types of all classes in the game.
 */
export declare enum Classes {
    Rogue = 768,
    Archer = 775,
    Wizard = 782,
    Priest = 784,
    Warrior = 797,
    Knight = 798,
    Paladin = 799,
    Assassin = 800,
    Necromancer = 801,
    Huntress = 802,
    Mystic = 803,
    Trickster = 804,
    Sorcerer = 805,
    Ninja = 806,
    Samurai = 785,
    Bard = 796
}
