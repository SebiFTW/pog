/**
 * Encrypts the text with a hard-coded public key.
 * @param msg The text to encrypt.
 */
export declare function encrypt(msg: string): string;
