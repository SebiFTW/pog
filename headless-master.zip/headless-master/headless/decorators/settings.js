"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const globalSettings = [];
//TODO: add plugin settings management
