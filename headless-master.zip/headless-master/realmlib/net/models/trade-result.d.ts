/**
 * The values used to represent the result of a trade
 */
export declare enum TradeResult {
    Successful = 0,
    PlayerCancelled = 1
}
