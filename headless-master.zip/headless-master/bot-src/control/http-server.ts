const http = require('http');

const defaultHost = 'localhost';
const defaultPort = 8888;

export class HttpServer {


    constructor(port: number = defaultPort) {

    }
}
