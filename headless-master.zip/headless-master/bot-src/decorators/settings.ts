import 'reflect-metadata';

const globalSettings: Array<{ [module: string]: any }> = [];
//TODO: add plugin settings management
